# in this directory run 'sh deploy'
cd ..
git pull origin main
tar -xzvf dist.tar.gz -C /var/www/bitab